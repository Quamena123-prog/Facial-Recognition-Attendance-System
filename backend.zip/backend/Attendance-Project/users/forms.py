# from django import forms
# from .models import Student

# class FaceEncodingForm(forms.ModelForm):
#     class Meta:
#         model = Student
#         fields = ['student_exam_number', 'firstname', 'lastname']
