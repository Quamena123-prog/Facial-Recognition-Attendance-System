use attendance_project;

select * from face_encoding;
delete from face_encoding where student_exam_number = 8111023;